//
//  ViewController.swift
//  DataBase
//
//  Created by Saloni Parekh on 2018-11-15.
//  Copyright © 2018 Saloni Parekh. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var context:NSManagedObjectContext!
    
    @IBOutlet weak var nameInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup your CoreData variable
        // ----------------------------------------
        
        // 1. Mandatory - copy and paste this
        // Explanation: try to create/initalize the appDelegate variable.
        // If creation fails, then quit the app
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        // 2. Mandatory - initialize the context variable
        // This variable gives you access to the CoreData functions
        self.context = appDelegate.persistentContainer.viewContext
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func SignUp(_ sender: Any) {
   
    
        print("Signup button pressed!")
        
        // Create the "row" you want to insert into the database
        // When using CoreData, you don't do a SQL statment
        // You create an OBJECT, and then insert the OBJECT
        
        // Below code is equivalent of:
        //      INSERT INTO User(email, password) VALUES ("michael@gmail.com", "1234")
        let p = Person(context: self.context)
        p.email = nameInput.text!
        p.password = passwordInput.text!
        
        do {
            // Save the user to the database
            // (Send the INSERT to the database)
            try self.context.save()
            print("Saved to database!")
        }
        catch {
            print("Error while saving to database")
        }
    
    }
    
    
    @IBAction func ShowData(_ sender: Any) {
        
        print("Show all users pressed!")
        
        // This is the same as:  SELECT * FROM User
        
        //SELECT * FROM User
        let fetchRequest:NSFetchRequest<Person> = Person.fetchRequest()
        
        //WHERE email="jenelle@gmail.com"
        //fetchRequest.predicate =  NSPredicate(format: "email == %@", "jenelle@gmail.com")
        
        // SQL: SELECT * FROM User WHERE email="jeenlle@gmil.com"
        
        do {
            // Send the "SELECT *" to the database
            //  results = variable that stores any "rows" that come back from the db
            // Note: The database will send back an array of User objects
            // (this is why I explicilty cast results as [User]
            let results = try self.context.fetch(fetchRequest) as [Person]
            
            // Loop through the database results and output each "row" to the screen
            print("Number of items in database: \(results.count)")
            
            for x in results {
                print("User Email: \(x.email)")
                print("User Password: \(x.password)")
            }
        }
        catch {
            print("Error when fetching from database")
        }
        
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        print("STEP 1: HELLO!!!!")
        
        //let screen2 = segue.destination as! SearchResultsViewController
        //screen2.personName = self.searchTextBox.text!
        
        let editScreen = segue.destination as! TableViewController
        
        //SELECT * FROM User WHERE email = .....
        let fetchRequest:NSFetchRequest<Person> = Person.fetchRequest()
        
        do {
            
            let results = try self.context.fetch(fetchRequest) as [Person]
            
            // Loop through the database results and output each "row" to the screen
            print("Number of items in database: \(results.count)")
            
            if (results.count == 1) {
                editScreen.person = results[0] as Person
            }
            
        }
        catch {
            print("Error when fetching from database")
        }
        
        
    }
    
    
    
    
    

}

